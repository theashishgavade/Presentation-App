import React, { useState } from "react";
import axios from "../../../services/api";

const StudentDashboard = ({ userId }) => {
  const [data, setData] = useState(null);

  const fetchDetails = async () => {
    try {
      const { data } = await axios.get(`/user/student/${userId}`);
      setData(data);
    } catch (err) {
      alert(err.response?.data || "Failed to fetch details.");
    }
  };

  const fetchPresentations = async () => {
    try {
      const { data } = await axios.get(`/presentation/student/${userId}`);
      setData(data);
    } catch (err) {
      alert(err.response?.data || "Failed to fetch presentations.");
    }
  };

  const fetchRatings = async () => {
    try {
      const { data } = await axios.get(`/rating/student/${userId}`);
      setData(data);
    } catch (err) {
      alert(err.response?.data || "Failed to fetch ratings.");
    }
  };

  const logout = async () => {
    try {
      await axios.post(`/user/logout`, null, { params: { email: userId } });
      alert("Logged out successfully!");
      window.location.href = "/login";
    } catch (err) {
      alert(err.response?.data || "Logout failed.");
    }
  };

  return (
    <div className="dashboard">
      <div className="actions">
        <button onClick={fetchDetails}>Show Details</button>
        <button onClick={fetchPresentations}>Get Assigned Presentations</button>
        <button onClick={fetchRatings}>Get Ratings</button>
        <button onClick={logout}>Logout</button>
      </div>
      <div className="data">
        {data && <pre>{JSON.stringify(data, null, 2)}</pre>}
      </div>
    </div>
  );
};

export default StudentDashboard;
