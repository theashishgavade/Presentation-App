import React, { useState } from "react";
import axios from "../../../services/api";

const AdminDashboard = ({ adminId }) => {
  const [data, setData] = useState(null);

  const fetchDetails = async () => {
    try {
      const { data } = await axios.get(`/user/admin/${adminId}`);
      setData(data);
    } catch (err) {
      alert(err.response?.data || "Failed to fetch admin details.");
    }
  };

  const fetchAllUsers = async () => {
    try {
      const { data } = await axios.get(`/user/admin/${adminId}/all`);
      setData(data);
    } catch (err) {
      alert(err.response?.data || "Failed to fetch users.");
    }
  };

  const logout = async () => {
    try {
      await axios.post(`/user/logout`, null, { params: { email: adminId } });
      alert("Logged out successfully!");
      window.location.href = "/login";
    } catch (err) {
      alert(err.response?.data || "Logout failed.");
    }
  };

  return (
    <div className="dashboard">
      <div className="actions">
        <button onClick={fetchDetails}>Show My Details</button>
        <button onClick={fetchAllUsers}>Fetch All Users</button>
        <button onClick={logout}>Logout</button>
      </div>
      <div className="data">
        {data && <pre>{JSON.stringify(data, null, 2)}</pre>}
      </div>
    </div>
  );
};

export default AdminDashboard;
