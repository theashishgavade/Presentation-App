import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "../../services/api";

const ChangeUserStatusPage = ({ adminId }) => {
  const [formData, setFormData] = useState({
    userId: "",
    status: "ACTIVE",
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.put(`/user/admin/${adminId}/status`, null, {
        params: {
          userId: formData.userId,
          status: formData.status,
        },
      });
      alert("User status updated successfully!");
      navigate("/admin-dashboard");
    } catch (err) {
      alert(err.response?.data || "Failed to update user status.");
    }
  };

  return (
    <div className="container">
      <h2>Change User Status</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="number"
          name="userId"
          placeholder="User ID"
          value={formData.userId}
          onChange={handleChange}
          required
        />
        <select name="status" value={formData.status} onChange={handleChange}>
          <option value="ACTIVE">Active</option>
          <option value="INACTIVE">Inactive</option>
        </select>
        <button type="submit">Update</button>
      </form>
      <button className="back-button" onClick={() => navigate("/admin-dashboard")}>
        Back
      </button>
    </div>
  );
};

export default ChangeUserStatusPage;
