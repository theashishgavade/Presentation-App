import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "../../../services/api";

const RatePresentationPage = ({ adminId }) => {
  const [formData, setFormData] = useState({
    userId: "",
    presentationId: "",
    communication: "1",
    confidence: "1",
    content: "1",
    interaction: "1",
    liveliness: "1",
    usageProps: "1",
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.put(`/rating/rate/userid/${formData.userId}/presentationid/${formData.presentationId}`, formData);
      alert("Rating submitted successfully!");
      navigate("/admin-dashboard");
    } catch (err) {
      alert(err.response?.data || "Failed to rate presentation.");
    }
  };

  return (
    <div className="container">
      <h2>Rate Presentation</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="number"
          name="userId"
          placeholder="Student ID"
          value={formData.userId}
          onChange={handleChange}
          required
        />
        <input
          type="number"
          name="presentationId"
          placeholder="Presentation ID"
          value={formData.presentationId}
          onChange={handleChange}
          required
        />
        {["communication", "confidence", "content", "interaction", "liveliness", "usageProps"].map((field) => (
          <div key={field}>
            <label>{field}</label>
            <select name={field} value={formData[field]} onChange={handleChange}>
              {[1, 2, 3, 4, 5].map((val) => (
                <option key={val} value={val}>
                  {val}
                </option>
              ))}
            </select>
          </div>
        ))}
        <button type="submit">Rate</button>
      </form>
      <button className="back-button" onClick={() => navigate("/admin-dashboard")}>
        Back
      </button>
    </div>
  );
};

export default RatePresentationPage;
