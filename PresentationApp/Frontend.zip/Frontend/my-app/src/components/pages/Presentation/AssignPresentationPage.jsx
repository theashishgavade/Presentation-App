import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../../../services/api";

const AssignPresentationPage = ({ adminId }) => {
  const [formData, setFormData] = useState({
    userId: "",
    course: "",
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await api.post(`/presentation/admin/assign/${formData.userId}`, { course: formData.course });
      alert("Presentation assigned successfully!");
      navigate("/admin-dashboard");
    } catch (err) {
      alert(err.response?.data || "Failed to assign presentation.");
    }
  };

  return (
    <div className="container">
      <h2>Assign Presentation</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="number"
          name="userId"
          placeholder="Student ID"
          value={formData.userId}
          onChange={handleChange}
          required
        />
        <input
          type="text"
          name="course"
          placeholder="Course Name"
          value={formData.course}
          onChange={handleChange}
          required
        />
        <button type="submit">Assign</button>
      </form>
      <button className="back-button" onClick={() => navigate("/admin-dashboard")}>
        Back
      </button>
    </div>
  );
};

export default AssignPresentationPage;
