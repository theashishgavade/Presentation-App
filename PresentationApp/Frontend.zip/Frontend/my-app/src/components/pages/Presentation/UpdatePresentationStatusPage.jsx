import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "../../../services/api";

const UpdatePresentationStatusPage = ({ userId }) => {
  const [formData, setFormData] = useState({
    presentationId: "",
    status: "ASSIGNED",
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.put(`/presentation/student/${userId}/status`, null, {
        params: {
          presentationId: formData.presentationId,
          status: formData.status,
        },
      });
      alert("Presentation status updated successfully!");
      navigate("/student-dashboard");
    } catch (err) {
      alert(err.response?.data || "Failed to update presentation status.");
    }
  };

  return (
    <div className="container">
      <h2>Update Presentation Status</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="number"
          name="presentationId"
          placeholder="Presentation ID"
          value={formData.presentationId}
          onChange={handleChange}
          required
        />
        <label>Status:</label>
        <select name="status" value={formData.status} onChange={handleChange}>
          <option value="ASSIGNED">Assigned</option>
          <option value="ONGOING">Ongoing</option>
        </select>
        <button type="submit">Update</button>
      </form>
      <button className="back-button" onClick={() => navigate("/student-dashboard")}>
        Back
      </button>
    </div>
  );
};

export default UpdatePresentationStatusPage;
