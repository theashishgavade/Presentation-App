import axios from 'axios';

// Set up axios instance to make API calls
const api = axios.create({
  baseURL: 'http://localhost:8080/', 
});


api.get('/endpoint')
  .then(response => console.log(response.data))
  .catch(error => console.error('Error fetching data:', error));

export default api;
